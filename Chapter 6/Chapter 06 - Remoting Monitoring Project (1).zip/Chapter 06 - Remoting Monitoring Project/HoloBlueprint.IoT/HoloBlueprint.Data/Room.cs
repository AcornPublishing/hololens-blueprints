﻿namespace HoloBlueprint.Data
{
    public class Room
    {
        public string RoomNumber { get; set; }
        public int Temperature { get; set; }
        public bool IsSmoke { get; set; }
        public bool IsFire { get; set; }
    }
}