﻿using System.Collections.Generic;

namespace HoloBlueprint.Data
{
    public class Wing
    {
        public string WingName { get; set; }
        public List<Floor> Floors { get; set; }
    }
}