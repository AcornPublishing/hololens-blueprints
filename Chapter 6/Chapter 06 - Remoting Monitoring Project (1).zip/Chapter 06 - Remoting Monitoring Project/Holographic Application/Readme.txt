From the Asset Folder, Open the Main Scene in Unity
Then Follow the Build and Run Test for Holographic Project
