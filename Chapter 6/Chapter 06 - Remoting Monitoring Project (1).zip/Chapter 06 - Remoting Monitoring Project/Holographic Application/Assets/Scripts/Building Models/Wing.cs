﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[Serializable]
public class Wing
{
    public string WingName;
    public List<Floor> Floors;
}