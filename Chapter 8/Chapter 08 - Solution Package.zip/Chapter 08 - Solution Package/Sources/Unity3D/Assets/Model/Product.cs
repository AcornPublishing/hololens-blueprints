﻿using System;

/// <summary>
/// Product 
/// </summary>
[Serializable]
public class Product
{
    public string Name;
    public string AssetURL;
    public string AssetName;
}