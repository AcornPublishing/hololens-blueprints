AssetAPI - Code Base for Backend API


Unity3D
From the Unity3D - Assets Folder, Open the Main Scene in Unity3D
Then Follow the Build and Run Test for Holographic Project


