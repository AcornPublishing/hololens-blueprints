From the Unity 3D Project --> Assets, Open the Main Scene in Unity
Then Follow the Build and Run Test for Holographic Project
